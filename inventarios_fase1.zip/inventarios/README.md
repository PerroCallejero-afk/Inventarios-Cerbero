# Sistema de Inventarios para PYMES

Sistema de gestión de inventarios on-premise, multi-almacén, pensado para
instalarse en Windows. Documento base completo: `docs/00_documento_base_v1.1.md`.

**Estado:** Fase 1 (infraestructura base). Ver el documento base para el plan.

## Requisitos de desarrollo

- [uv](https://docs.astral.sh/uv/) (instala Python 3.12+ automáticamente)
- [just](https://github.com/casey/just)
- Docker (Docker Desktop en Windows) para PostgreSQL

## Inicio rápido (Windows o Linux/Mac)

```
just setup      # dependencias + .env con clave aleatoria
just db         # PostgreSQL 18 + Adminer (http://localhost:8080)
just api        # API en http://127.0.0.1:8000  ->  /health  y  /docs
just test       # pruebas sin base de datos
just test-int   # pruebas contra PostgreSQL real
```

### Pila completa en Docker (postgres + api + Caddy con HTTPS)

```
just up         # https://localhost/health  (certificado interno de Caddy)
just down
```

La base de datos y la API no exponen puertos al exterior; solo Caddy (80/443).
Adminer y el puerto 5432 existen únicamente con `docker-compose.dev.yml`.

## Notas de Windows

- Usa siempre `just api` o `python -m app.run` (ver `docs/decisiones/001`).
- PostgreSQL 18 en Docker monta su volumen en `/var/lib/postgresql`.
- Los saltos de línea se normalizan con `.gitattributes`.
- El instalador nativo de Windows (sin Docker) llega en la Fase 6.

## Estructura actual

```
backend/app/core/      configuración, base de datos, bucle de eventos
backend/app/modules/   módulos de dominio (por ahora: health)
backend/tests/         unit/ (sin BD) e integration/ (PostgreSQL real)
deploy/caddy/          proxy HTTPS
docs/                  documento base y decisiones (ADR)
```
