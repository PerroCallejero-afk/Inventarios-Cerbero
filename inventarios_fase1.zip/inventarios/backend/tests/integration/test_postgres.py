import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from app.core.config import get_settings
from app.main import create_app

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_conexion_asincrona_y_postgres_18():
    """Falla en Windows si el bucle de eventos no es SelectorEventLoop."""
    engine = create_async_engine(get_settings().database_url)
    try:
        async with engine.connect() as conn:
            version = (await conn.execute(text("SHOW server_version_num"))).scalar_one()
            assert int(version) >= 180000
            generated = (await conn.execute(text("SELECT uuidv7()"))).scalar_one()
            assert generated.version == 7
    finally:
        await engine.dispose()


def test_health_con_base_real():
    with TestClient(create_app()) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["database"] == "ok"
