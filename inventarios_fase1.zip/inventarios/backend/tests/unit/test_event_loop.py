import asyncio

from app.core.event_loop import loop_factory


def test_loop_factory_devuelve_selector_loop():
    loop = loop_factory()
    try:
        assert isinstance(loop, asyncio.SelectorEventLoop)
    finally:
        loop.close()
