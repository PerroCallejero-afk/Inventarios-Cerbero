from fastapi.testclient import TestClient

from app.core.database import get_session
from app.main import create_app


class FakeSession:
    def __init__(self, fail: bool = False) -> None:
        self.fail = fail

    async def execute(self, *_args, **_kwargs) -> None:
        if self.fail:
            raise ConnectionError("sin base de datos")


def make_client(fail: bool) -> TestClient:
    app = create_app()

    async def override():
        yield FakeSession(fail=fail)

    app.dependency_overrides[get_session] = override
    return TestClient(app)


def test_live_no_toca_la_base():
    client = TestClient(create_app())
    response = client.get("/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_health_ok():
    response = make_client(fail=False).get("/health")
    assert response.status_code == 200
    assert response.json()["database"] == "ok"


def test_health_devuelve_503_si_la_base_falla():
    response = make_client(fail=True).get("/health")
    assert response.status_code == 503
    assert response.json()["database"] == "down"
