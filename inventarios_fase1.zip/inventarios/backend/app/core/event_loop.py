"""Bucle de eventos compatible con psycopg 3 asíncrono.

En Windows, asyncio usa ProactorEventLoop por defecto y psycopg async
exige SelectorEventLoop. Ver docs/decisiones/001-event-loop-windows.md.
"""

import asyncio
import sys


def loop_factory() -> asyncio.AbstractEventLoop:
    return asyncio.SelectorEventLoop()


def configure_event_loop_policy() -> None:
    """Respaldo para entornos donde no controlamos quién crea el bucle."""
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
