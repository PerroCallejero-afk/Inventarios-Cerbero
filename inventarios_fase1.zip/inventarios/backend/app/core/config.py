from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Los archivos se buscan en el directorio actual y en el superior,
    # para que funcione al ejecutar desde la raíz o desde backend/.
    model_config = SettingsConfigDict(
        env_file=("../.env", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "Sistema de Inventarios"
    app_version: str = "0.1.0"
    app_env: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "info"
    docs_enabled: bool = True
    database_url: str = "postgresql+psycopg://inventarios:change_me@localhost:5432/inventarios"


@lru_cache
def get_settings() -> Settings:
    return Settings()
