"""Punto de entrada oficial: `python -m app.run`.

Arranca Uvicorn con SelectorEventLoop en todas las plataformas
(loop="none" evita que Uvicorn elija ProactorEventLoop en Windows).
"""

import asyncio

import uvicorn

from app.core.config import get_settings
from app.core.event_loop import loop_factory


def main() -> None:
    settings = get_settings()
    config = uvicorn.Config(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level,
        loop="none",
    )
    server = uvicorn.Server(config)
    asyncio.run(server.serve(), loop_factory=loop_factory)


if __name__ == "__main__":
    main()
