from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_session

router = APIRouter(tags=["health"])


@router.get("/health/live")
async def live() -> dict[str, str]:
    """El proceso responde. No toca la base de datos."""
    return {"status": "ok"}


@router.get("/health")
async def health(session: AsyncSession = Depends(get_session)) -> JSONResponse:
    """El proceso responde y la base de datos es alcanzable."""
    settings = get_settings()
    body = {
        "app": settings.app_name,
        "version": settings.app_version,
        "env": settings.app_env,
    }
    try:
        await session.execute(text("SELECT 1"))
    except Exception:
        return JSONResponse({**body, "status": "error", "database": "down"}, status_code=503)
    return JSONResponse({**body, "status": "ok", "database": "ok"})
