# ADR 001: SelectorEventLoop en todas las plataformas

**Estado:** aceptada

## Contexto
En Windows, asyncio usa `ProactorEventLoop` por defecto. psycopg 3 en modo
asíncrono requiere `SelectorEventLoop` y falla con `InterfaceError` en Proactor.
Uvicorn elige el bucle por su cuenta, por lo que configurar solo la política
de asyncio no es suficiente en todas las versiones.

## Decisión
- El arranque oficial es `python -m app.run`, que usa `loop="none"` en Uvicorn
  y ejecuta el servidor con `asyncio.run(..., loop_factory=SelectorEventLoop)`.
- Como respaldo, `app.main` fija `WindowsSelectorEventLoopPolicy` en Windows.
- Los servicios de Windows (WinSW, Fase 6) deben lanzar `python -m app.run`.
- CI ejecuta las pruebas unitarias en Windows y en Linux; las de integración
  (que ejercitan psycopg async) se ejecutan en Linux con PostgreSQL 18.

## Consecuencias
- No se usa `--reload` de Uvicorn con este arranque. En desarrollo se reinicia
  con `just api`. Verificar en Windows si se necesita recarga en caliente.
- Pendiente (Fase 1, cierre): ejecutar `just test-int` en una máquina Windows
  real contra PostgreSQL 18 para confirmar el comportamiento.
