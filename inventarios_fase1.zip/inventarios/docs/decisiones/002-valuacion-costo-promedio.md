# ADR 002: Valuación por costo promedio ponderado

**Estado:** aceptada

Costo promedio ponderado por producto y almacén. `existencias.costo_promedio`
y, por movimiento, `costo_unitario`, `existencia_anterior`, `existencia_nueva`.
PEPS queda descartado por ahora; reabrir si un cliente lo exige.
