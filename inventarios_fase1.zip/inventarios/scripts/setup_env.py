"""Crea .env desde .env.example con una clave de base de datos aleatoria."""

import pathlib
import secrets

ROOT = pathlib.Path(__file__).resolve().parent.parent
PLACEHOLDER = "CAMBIAR_ESTA_CLAVE"


def main() -> None:
    target = ROOT / ".env"
    if target.exists():
        print(".env ya existe; no se modifica.")
        return
    text = (ROOT / ".env.example").read_text(encoding="utf-8")
    text = text.replace(PLACEHOLDER, secrets.token_hex(16))
    target.write_text(text, encoding="utf-8", newline="\n")
    print(".env creado con una clave aleatoria.")


if __name__ == "__main__":
    main()
